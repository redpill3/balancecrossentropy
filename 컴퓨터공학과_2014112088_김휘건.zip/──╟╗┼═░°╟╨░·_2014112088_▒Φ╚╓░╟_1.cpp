
#include <iostream>

#include <time.h> 

#define infoNIL 0
#define itemMIN -1
#define black 0
#define red 1
typedef int itemType;
typedef int infoType;

class RBtree {
private:
	struct node {
		itemType key, tag;
		infoType Info;
		struct node *l, *r;
		node(itemType k, infoType i, itemType t, struct node *ll, struct node *rr) {
			key = k; Info = i; tag = t; l = ll; r = rr;
		}
	};
	struct node *head, *tail, *x, *p, *g, *gg, *z;

public:
	int insertCount;
	int searchCount;

	RBtree(int max) {
		z = new node(0, infoNIL, black, 0, 0);
		z->l = z; z->r = z;
		head = new node(itemMIN, infoNIL, black, z, z);
		this->insertCount = 0;
		this->searchCount = 0;
	}

	void insert(itemType k, infoType info) {
		x = head; p = head; g = head;
		while (x != z) {
			gg = g; g = p; p = x;
			x = (k < x->key) ? x->l : x->r;
			insertCount++;
			if (x->l->tag && x->r->tag) split(k);
		}
		x = new node(k, info, red, z, z);
		if (k < p->key) p->l = x; else p->r = x;
		insertCount++;
		split(k); head->r->tag = black;
	}

	struct node *rotate(itemType k, struct node *y) {
		struct node *high, *low;
		high = (k < y->key) ? y->l : y->r;
		insertCount++;
		if (k < high->key) { low = high->l; high->l = low->r; low->r = high; insertCount++;}
		else { low = high->r; high->r = low->l; low->l = high; }
		if (k < y->key) y->l = low; else y->r = low;
		insertCount++;
		return low;
	}

	void split(itemType k) {
		x->tag = red; x->l->tag = black; x->r->tag = black;
		if (p->tag) {
			g->tag = red;
			if (k < g->key != k < p->key) p = rotate(k, g);
			insertCount++;
			x = rotate(k, gg);
			x->tag = black;
		}
	}

	infoType search(itemType v) {
		struct node *x = head->r;
		z->key = v;  // �Ʒ� �ݺ����� ������ ����� ����
		while (v != x->key) { x = (v < x->key) ? x->l : x->r; searchCount++; }
		return x->Info;
	}
};

class BST {
private:
	struct node {
		itemType key; infoType info;
		struct node *l, *r;
		node(itemType k, infoType i, struct node *ll, struct node *rr)  // node ������ �ʱⰪ �ο� ���� 
		{
			key = k; info = i; l = ll; r = rr;
		};
	};
	struct node *head, *z; // z : List�� ���� ��ǥ�ϴ� node pointer ? NULL�� �ش�
public:
	int insertCount;
	int searchCount;

	BST(int max) {
		z = new node(0, infoNIL, 0, 0);
		head = new node(itemMIN, infoNIL, z, z);
		this->insertCount = 0;
		this->searchCount = 0;
	}


	infoType BSTsearch(itemType v) {
		struct node *x = head->r;
		z->key = v;  // �Ʒ� �ݺ����� ������ ����� ����
		while (v != x->key) { x = (v < x->key) ? x->l : x->r; searchCount++; }
		return x->info;
	}
	void BSTinsert(itemType v, infoType info) {
		struct node *p, *x;
		p = head; x = head->r;
		while (x != z) { p = x; x = (v < x->key) ? x->l : x->r; insertCount++;}
		x = new node(v, info, z, z);
		if (v < p->key) p->l = x; else p->r = x;
		insertCount++;
	}
	//T1���� ���� ��ȸ�� ���� ������� element  ����, �� T2 ����, T2 ����
	BST& makeT2(int n) {
		BST T2(n);
		inorder(head, T2);
		return T2;
	}	
	
	//T2����
	void inorder(struct node *nd, BST &outputBST) {
		if (nd) { // pointer�� null�� �ƴ϶�� 
			inorder(nd->l, outputBST);
			if (nd->info != infoNIL)
				outputBST.BSTinsert(nd->info, nd->key);
			inorder(nd->r, outputBST);
		}
	}

	//T1���� ���� ��ȸ�� ���� ������� element  ����, �� T2 ����, T2 ����
	RBtree& makeT3(int n) {
		RBtree T3(n);
		inorder(head, T3);
		return T3;
	}

	//T3����
	void inorder(struct node *nd, RBtree &outputRBT) {
		if (nd) { // pointer�� null�� �ƴ϶�� 
			inorder(nd->l, outputRBT);
			if (nd->info != infoNIL)
				outputRBT.insert(nd->info, nd->key);
			inorder(nd->r, outputRBT);
		}
	}


};

int main()
{
	srand(time(NULL));
	int N = 20000;
	std::cin >> N;
	srand(time(NULL));

	//���� �迭 ����
	int *arrayB = new int[N];
	for (int i = 0; i < N; i++) {
		arrayB[i] = N - i;
	}
	int temp;
	int rn;
	for (int i = 0; i < N - 1; i++) {
		rn = rand() % (N - i) + i;
		temp = arrayB[i];
		arrayB[i] = arrayB[rn];
		arrayB[rn] = temp;
	}

	//BST t1 �ڷᱸ�� ���� �� B�迭 ����
	BST t1(N);
	for (int i = 0; i < N; i++) {
		t1.BSTinsert(arrayB[i], (infoType)arrayB[i]);
	}
	//T1 ���� ��� �� Ƚ��
	std::cout << (float)t1.insertCount / N << std::endl;
	//T2����
	BST T2 = t1.makeT2(N);
	//T1 ���� ��� �� Ƚ��
	std::cout << (float)T2.insertCount / N << std::endl;
	//T3����
	RBtree T3 = t1.makeT3(N);
	//T1 ���� ��� �� Ƚ��
	std::cout << (float)T3.insertCount / N << std::endl;

	std::cout << std::endl;


	for (int searchKey = 1; searchKey <= N; searchKey++) {
		t1.BSTsearch(searchKey);
	}
	std::cout << (float)t1.searchCount / N << std::endl;

	for (int searchKey = 1; searchKey <= N; searchKey++) {
		T2.BSTsearch(searchKey);	
	}
	std::cout << (float)T2.searchCount / N << std::endl;

	for (int searchKey = 1; searchKey <= N; searchKey++) {
		T3.search(searchKey);
	}
	std::cout << (float)T3.searchCount / N << std::endl;


}


