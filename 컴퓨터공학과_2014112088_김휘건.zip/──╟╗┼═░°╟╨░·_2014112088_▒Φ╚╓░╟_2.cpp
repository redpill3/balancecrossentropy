
#include <iostream>

#include <time.h> 

#define infoNIL 0
#define itemMIN -1
#define black 0
#define red 1



typedef int itemType;
typedef int infoType;

class RBtree {
private:
	struct node {
		itemType key, tag;
		infoType Info;
		struct node *l, *r;
		node(itemType k, infoType i, itemType t, struct node *ll, struct node *rr) {
			key = k; Info = i; tag = t; l = ll; r = rr;
		}
	};
	struct node *head, *tail, *x, *p, *g, *gg, *z;

public:
	int insertCount;
	int searchCount;

	RBtree(int max) {
		z = new node(0, infoNIL, black, 0, 0);
		z->l = z; z->r = z;
		head = new node(itemMIN, infoNIL, black, z, z);
		this->insertCount = 0;
		this->searchCount = 0;
	}

	void insert(itemType k, infoType info) {
		x = head; p = head; g = head;
		while (x != z) {
			gg = g; g = p; p = x;
			x = (k < x->key) ? x->l : x->r;
			insertCount++;
			if (x->l->tag && x->r->tag) split(k);
		}
		x = new node(k, info, red, z, z);
		if (k < p->key) p->l = x; else p->r = x;
		insertCount++;
		split(k); head->r->tag = black;
	}

	struct node *rotate(itemType k, struct node *y) {
		struct node *high, *low;
		high = (k < y->key) ? y->l : y->r;
		insertCount++;
		if (k < high->key) { low = high->l; high->l = low->r; low->r = high; insertCount++;}
		else { low = high->r; high->r = low->l; low->l = high; }
		if (k < y->key) y->l = low; else y->r = low;
		insertCount++;
		return low;
	}

	void split(itemType k) {
		x->tag = red; x->l->tag = black; x->r->tag = black;
		if (p->tag) {
			g->tag = red;
			if (k < g->key != k < p->key) p = rotate(k, g);
			insertCount++;
			x = rotate(k, gg);
			x->tag = black;
		}
	}

	infoType search(itemType v) {
		struct node *x = head->r;
		z->key = v;  // �Ʒ� �ݺ����� ������ ����� ����
		while (v != x->key) { x = (v < x->key) ? x->l : x->r; searchCount++; }
		return x->Info;
	}
};

class chainHashTable {
private:
#define MAX_HASH 10
#define HASH_KEY(key) key%MAX_HASH

	typedef struct Node
	{
		itemType id;
		Node* hashNext;
	}Node;

	int size;
	Node** hashTable;

public:
	int insertCount;
	int searchCount;


	chainHashTable(int size) {
		this->size = size;
		this->insertCount = 0;
		this->searchCount = 0;
		hashTable = new Node*[size];
	}

	void  AddHashData(int key)
	{
		Node* node = (Node*)malloc(sizeof(Node));
		node->id = key;
		node->hashNext = NULL;
		int hash_key = key % size;

		if (hashTable[hash_key] == NULL)
		{
			hashTable[hash_key] = node;
			insertCount++;
		}
		else
		{
			node->hashNext = hashTable[hash_key];
			hashTable[hash_key] = node;
			insertCount++;
		}
	}

	itemType FindHashData(int id)
	{
		int hash_key = id % size;
		if (hashTable[hash_key] == NULL)
			return NULL;

		if (hashTable[hash_key]->id == id)
		{
			searchCount++;
			return hashTable[hash_key]->id;
		}
		else
		{
			Node* node = hashTable[hash_key];
			while (node->hashNext)
			{	
				searchCount++;
				if (node->hashNext->id == id)
				{
					
					return node->hashNext->id;
				}
				node = node->hashNext;
			}
		}
		return  NULL;
	}
};

int main()
{
	srand(time(NULL));
	int N = 20000;
	std::cin >> N;
	srand(time(NULL));

	//���� �迭 ����
	int *arrayB = new int[N];
	for (int i = 0; i < N; i++) {
		arrayB[i] = N - i;
	}
	int temp;
	int rn;
	for (int i = 0; i < N - 1; i++) {
		rn = rand() % (N - i) + i;
		temp = arrayB[i];
		arrayB[i] = arrayB[rn];
		arrayB[rn] = temp;
	}


	//T3 ����
	RBtree T3(N);
	for (int i = 0; i < N; i++) {
		T3.insert(arrayB[i], (infoType)arrayB[i]);
	}
	std::cout << (float)T3.insertCount / N << std::endl;

	//Hash Table(11) ����
	chainHashTable hst1(11);
	for (int i = 0; i < N; i++) {
		hst1.AddHashData(arrayB[i]);
	}
	std::cout << (float)hst1.insertCount / N << std::endl;

	//Hash Table(101) ����
	chainHashTable hst2(101);
	for (int i = 0; i < N; i++) {
		hst2.AddHashData(arrayB[i]);
	}
	std::cout << (float)hst2.insertCount / N << std::endl;

	//Hash Table(1009) ����
	chainHashTable hst3(1009);
	for (int i = 0; i < N; i++) {
		hst3.AddHashData(arrayB[i]);
	}
	std::cout << (float)hst3.insertCount / N << std::endl;

	std::cout << std::endl;

	//T3��� �� ȸ��
	for (int searchKey = 1; searchKey <= N; searchKey++) {
		T3.search(searchKey);
	}
	std::cout << (float)T3.searchCount / N << std::endl;



	
	//Hash Table(11) ��� �� ȸ��
	for (int searchKey = 1; searchKey <= N; searchKey++) {
		hst1.FindHashData(searchKey);
	}
	std::cout << (float)hst1.searchCount / N << std::endl;

	
	
	//Hash Table(101) ��� �� ȸ��
	for (int searchKey = 1; searchKey <= N; searchKey++) {
		hst2.FindHashData(searchKey);
	}
	std::cout << (float)hst2.searchCount / N << std::endl;

	//Hash Table(1009) ��� �� ȸ��
	for (int searchKey = 1; searchKey <= N; searchKey++) {
		hst3.FindHashData(searchKey);
	}
	std::cout << (float)hst3.searchCount / N << std::endl;
	
}


